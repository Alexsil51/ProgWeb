package com.example.cadastro_musicas.controller;

import com.example.model.Musica;
import com.example.cadastro_musicas.repository.MusicaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/musicas")
public class MusicaController {

    @Autowired
    private MusicaRepository musicaRepository;

    @PostMapping
    public ResponseEntity<?> salvarMusica(@Valid @RequestBody Musica musica, BindingResult result) {
        // Validação dos campos
        if (result.hasErrors()) {
            Map<String, String> erros = new HashMap<>();
            result.getFieldErrors().forEach(error -> {
                erros.put(error.getField(), error.getDefaultMessage());
            });
            return ResponseEntity.badRequest().body(erros);
        }
        
        // Garante a data de cadastro
        musica.setDataCadastro(LocalDateTime.now());
        
        try {
            Musica musicaSalva = musicaRepository.save(musica);
            return ResponseEntity.status(201).body(musicaSalva);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Erro ao salvar música");
        }
    }

    // Adicione também os outros métodos essenciais:
    @GetMapping
    public ResponseEntity<List<Musica>> listarTodas() {
        return ResponseEntity.ok(musicaRepository.findAll());
    }
}