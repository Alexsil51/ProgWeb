package com.example.cadastro_musicas.service;

import com.example.cadastro_musicas.repository.MusicaRepository;
import com.example.model.Musica;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MusicaService {
    @Autowired
    private MusicaRepository musicaRepository;

    public List<Musica> listarTodas() {
        return musicaRepository.findAll();
    }

    public Musica salvar(Musica musica) {
        return musicaRepository.save(musica);
    }
}