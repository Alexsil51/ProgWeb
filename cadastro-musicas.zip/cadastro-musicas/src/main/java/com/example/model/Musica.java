
package com.example.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Musica {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "O título não pode estar em branco")
    private String titulo;
    
    @NotBlank(message = "O artista não pode estar em branco")
    private String artista;
    
    @NotNull(message = "O ano de lançamento não pode ser nulo")
    @Min(value = 1900, message = "O ano deve ser maior ou igual a 1900")
    @Max(value = 2099, message = "O ano deve ser menor ou igual a 2099")
    private Integer anoLancamento;
    
    //@Column(name = "data_cadastro") // Opcional - define o nome da coluna no banco
    //private LocalDateTime dataCadastro;
    @Column(name = "data_cadastro")
    private LocalDateTime dataCadastro;
    
    @PrePersist
    protected void onCreate() {
        this.dataCadastro = LocalDateTime.now();
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public Integer getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(Integer anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public LocalDateTime getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDateTime dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
}