// ==================== CONSTANTES E INICIALIZAÇÃO ====================
const API_URL = '/api/musicas';

// ==================== EVENTOS PRINCIPAIS ====================
document.addEventListener('DOMContentLoaded', function() {
    const formMusica = document.getElementById('formMusica');
    const btnCancelar = document.getElementById('btnCancelar');

    // Limpar mensagens de erro
    function limparErros() {
        document.querySelectorAll('.erro-validacao').forEach(el => {
            el.textContent = '';
        });
    }

    // Mostrar erros de validação
    function mostrarErros(erros) {
        limparErros();
        
        for (const [campo, mensagem] of Object.entries(erros)) {
            const elementoErro = document.getElementById(`erro${campo.charAt(0).toUpperCase() + campo.slice(1)}`);
            if (elementoErro) {
                elementoErro.textContent = mensagem;
            }
        }
    }

    // Enviar formulário
    formMusica.addEventListener('submit', function(e) {
        e.preventDefault();
        limparErros();

        const formData = {
            titulo: document.getElementById('titulo').value,
            artista: document.getElementById('artista').value,
            anoLancamento: parseInt(document.getElementById('anoLancamento').value)
        };

        fetch('/api/musicas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(err => { throw err; });
            }
            return response.json();
        })
        .then(data => {
            alert('Música cadastrada com sucesso!');
            window.location.href = '/'; // Redireciona para a listagem
        })
        .catch(error => {
            if (typeof error === 'object') {
                mostrarErros(error);
            } else {
                console.error('Erro:', error);
            }
        });
    });

    // Cancelar
    btnCancelar.addEventListener('click', function() {
        window.location.href = '/';
    });
});