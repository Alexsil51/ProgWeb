package com.example.cadastro_musicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroMusicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
