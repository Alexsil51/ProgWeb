package com.music.project.entite;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
@Table(name = "musicas_cadastradasdb")
public class Music {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @NotBlank(message = "O nome do artista não pode estar em branco")
    @Size(min = 2, max = 100, message = "O nome do artista deve ter entre 2 e 100 caracteres")
    @Column(name = "nome_artista")
    private String artistName;
    
    @NotBlank(message = "O nome da música não pode estar em branco")
    @Size(min = 2, max = 100, message = "O nome da música deve ter entre 2 e 100 caracteres")
    @Column(name = "nome_musica")
    private String musicName;
    
    @Min(value = 1900, message = "O ano de lançamento deve ser igual ou superior a 1900")
    @Column(name = "ano_lancamento")
    private int releaseYear;

	public Music() {
	}


	public Music(int id, String artistName, String musicName, int releaseYear) {
		this.id = id;
		this.artistName = artistName;
		this.musicName = musicName;
		this.releaseYear = releaseYear;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getArtistName() {
		return artistName;
	}


	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}


	public String getMusicName() {
		return musicName;
	}


	public void setMusicName(String musicName) {
		this.musicName = musicName;
	}


	public int getReleaseYear() {
		return releaseYear;
	}


	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
}
