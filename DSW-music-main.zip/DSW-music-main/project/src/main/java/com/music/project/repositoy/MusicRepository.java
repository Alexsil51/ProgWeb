package com.music.project.repositoy;


import org.springframework.data.jpa.repository.JpaRepository;

import com.music.project.entite.Music;

public interface MusicRepository extends JpaRepository<Music, Integer>{
	
	
}
