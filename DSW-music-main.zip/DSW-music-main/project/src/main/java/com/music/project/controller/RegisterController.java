package com.music.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.music.project.entite.Music;
import com.music.project.service.MusicService;

@Controller
@RequestMapping("/cadastro")
public class RegisterController {

    @Autowired
    MusicService service;

    @PostMapping("/listagem")
    public String registerMusic(@RequestParam("artist") String artist, @RequestParam("song") String song,
                                @RequestParam("year") int year) {
        Music music = new Music();
        music.setArtistName(artist);
        music.setMusicName(song);
        music.setReleaseYear(year);

        service.saveMusic(music);

        return "redirect:/listagem";
    }
}
