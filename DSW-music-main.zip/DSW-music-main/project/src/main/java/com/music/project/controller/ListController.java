package com.music.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.music.project.entite.Music;
import com.music.project.service.MusicService;

@Controller
@RequestMapping("/listagem")
public class ListController {

    @Autowired
    private MusicService musicService;

    @GetMapping
    public String showListPage(Model model) {
        List<Music> musicas = musicService.getAll();
        model.addAttribute("musicas", musicas);
        return "listagem";
    }

    @PostMapping("/cadastro")
    public String redirectToCadastro() {
        return "redirect:/cadastro";
    }
}
